<?
// Config - Start

$db_host = "localhost";  // Default = Localhost
$db_user = "root";
$db_password = "danielle";
$db_name = "character";  // Should be 'character' or 'logon' by default. (depends on your db)




$sender_id = "0";

// Config - End
?>